var MEWUpdater_ = new Class({
    initialize: function(functionName) {
        this.update_ = window[functionName];        
    },
                           
    // This method accumulates updates until the page is fully loaded.
    requestUpdate: function(){
        this.needsUpdate = true;
    },

    update: function(){
        this.update_();
        this.needsUpdate = false;
    },

    // This method needs to be called after the whole page has been loaded.
    updateIfNeeded: function(){
        if(this.needsUpdate) {
            this.update();
            return true;
        }
        return false;
    }
});
